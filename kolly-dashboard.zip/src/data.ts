
export const companies = [
  {
    id: "nykaa",
    name: "Nykaa",
    logoUrl: "https://logo.clearbit.com/nykaa.com",
    statCards: { aum: 4500, irrt: 13.2, moic: 1.9, costRatio: 34 },
    structure: [
      { label: "Marketing", value: 40 },
      { label: "Ops", value: 30 },
      { label: "Tech", value: 20 },
      { label: "Admin", value: 10 },
    ],
    profitability: [
      { month: "Jan", profit: 2.1 },
      { month: "Feb", profit: 2.5 },
      { month: "Mar", profit: 3.0 },
    ],
  },
  {
    id: "biocon",
    name: "Biocon",
    logoUrl: "https://logo.clearbit.com/biocon.com",
    statCards: { aum: 8000, irrt: 11.5, moic: 2.1, costRatio: 28 },
    structure: [
      { label: "R&D", value: 45 },
      { label: "Manufacturing", value: 35 },
      { label: "Admin", value: 20 },
    ],
    profitability: [
      { month: "Jan", profit: 3.0 },
      { month: "Feb", profit: 3.4 },
      { month: "Mar", profit: 4.1 },
    ],
  },
  {
    id: "mamaearth",
    name: "Mamaearth",
    logoUrl: "https://logo.clearbit.com/mamaearth.in",
    statCards: { aum: 3700, irrt: 14.8, moic: 2.0, costRatio: 30 },
    structure: [
      { label: "Marketing", value: 50 },
      { label: "Tech", value: 25 },
      { label: "Product Dev", value: 25 },
    ],
    profitability: [
      { month: "Jan", profit: 1.9 },
      { month: "Feb", profit: 2.2 },
      { month: "Mar", profit: 2.6 },
    ],
  },
  {
    id: "mobikwik",
    name: "MobiKwik",
    logoUrl: "https://logo.clearbit.com/mobikwik.com",
    statCards: { aum: 4200, irrt: 12.1, moic: 1.7, costRatio: 36 },
    structure: [
      { label: "Infra", value: 40 },
      { label: "Tech", value: 35 },
      { label: "Marketing", value: 25 },
    ],
    profitability: [
      { month: "Jan", profit: 2.0 },
      { month: "Feb", profit: 2.3 },
      { month: "Mar", profit: 2.7 },
    ],
  },
  {
    id: "sugar",
    name: "Sugar Cosmetics",
    logoUrl: "https://logo.clearbit.com/sugarcosmetics.com",
    statCards: { aum: 3100, irrt: 15.0, moic: 2.4, costRatio: 32 },
    structure: [
      { label: "Retail", value: 35 },
      { label: "Marketing", value: 40 },
      { label: "Product", value: 25 },
    ],
    profitability: [
      { month: "Jan", profit: 2.4 },
      { month: "Feb", profit: 2.6 },
      { month: "Mar", profit: 3.1 },
    ],
  }
];
